.. The Fifty State Project documentation master file, created by
   sphinx-quickstart on Fri Jun 12 11:25:50 2009.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Fifty State Project Documentation
=================================

Contents:

.. toctree::
   :maxdepth: 3

   README
   scripts/pyutils/README
   scripts/rbutils/README
   scripts/state-specific-index
   scripts/contributing



Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

